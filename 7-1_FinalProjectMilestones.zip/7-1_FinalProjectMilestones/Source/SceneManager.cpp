#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
	m_objectMaterials.clear();
}

void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL mat;
	mat.tag = "default";
	mat.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	mat.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
	mat.shininess = 32.0f;
	m_objectMaterials.push_back(mat);
}

void SceneManager::SetupSceneLights()
{
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
	m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(0.0f, 15.0f, 0.0f));
	m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.3f, 0.25f, 0.15f));
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(1.0f, 0.95f, 0.85f));
	m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(1.0f, 0.95f, 0.85f));
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);
}

bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width, height, colorChannels;
	GLuint textureID;
	stbi_set_flip_vertically_on_load(true);
	unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);
	if (image)
	{
		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
			return false;
		glGenerateMipmap(GL_TEXTURE_2D);
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0);
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;
		return true;
	}
	return false;
}

void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

int SceneManager::FindTextureID(std::string tag)
{
	for (int i = 0; i < m_loadedTextures; i++)
		if (m_textureIDs[i].tag == tag)
			return m_textureIDs[i].ID;
	return -1;
}

int SceneManager::FindTextureSlot(std::string tag)
{
	for (int i = 0; i < m_loadedTextures; i++)
		if (m_textureIDs[i].tag == tag)
			return i;
	return -1;
}

bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	for (auto& mat : m_objectMaterials)
	{
		if (mat.tag == tag)
		{
			material = mat;
			return true;
		}
	}
	return false;
}

void SceneManager::SetTransformations(glm::vec3 scale, float xRot, float yRot, float zRot, glm::vec3 pos, glm::vec3 offset)
{
	glm::mat4 modelView = glm::translate(pos + offset)
		* glm::rotate(glm::radians(zRot), glm::vec3(0, 0, 1))
		* glm::rotate(glm::radians(yRot), glm::vec3(0, 1, 0))
		* glm::rotate(glm::radians(xRot), glm::vec3(1, 0, 0))
		* glm::scale(scale);
	m_pShaderManager->setMat4Value(g_ModelName, modelView);
}

void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
	m_pShaderManager->setIntValue(g_UseTextureName, false);
	m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(r, g, b, a));
}

void SceneManager::SetShaderTexture(std::string tag)
{
	m_pShaderManager->setIntValue(g_UseTextureName, true);
	int slot = FindTextureSlot(tag);
	m_pShaderManager->setSampler2DValue(g_TextureValueName, slot);
}

void SceneManager::SetTextureUVScale(float u, float v)
{
	m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
}

void SceneManager::SetShaderMaterial(std::string tag)
{
	OBJECT_MATERIAL mat;
	if (FindMaterial(tag, mat))
	{
		m_pShaderManager->setVec3Value("material.diffuseColor", mat.diffuseColor);
		m_pShaderManager->setVec3Value("material.specularColor", mat.specularColor);
		m_pShaderManager->setFloatValue("material.shininess", mat.shininess);
	}
}

void SceneManager::PrepareScene()
{
	DefineObjectMaterials();
	SetupSceneLights();
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadBoxMesh();
	CreateGLTexture("textures/waterbottle.jpg", "BottleTexture");
	CreateGLTexture("textures/water.jpg", "WaterTexture");
	CreateGLTexture("textures/wood.jpg", "WoodTexture");
	CreateGLTexture("textures/coaster.jpg", "CoasterTexture");
	CreateGLTexture("textures/laptopbase.jpg", "LaptopbaseTexture");
	CreateGLTexture("textures/laptopscreen.jpg", "LaptopscreenTexture");
	CreateGLTexture("textures/laptopwindow.jpg", "LaptopwindowTexture");
	CreateGLTexture("textures/rug.jpg", "RugTexture");
	BindGLTextures();
}

void SceneManager::RenderScene()
{
	SetShaderMaterial("default");
	glm::vec3 scale, position;
	float xRot = 0, yRot = 0, zRot = 0;

	// Rug
	scale = glm::vec3(25, 1, 15);
	position = glm::vec3(0, 0.1f, 0);
	SetTransformations(scale, xRot, yRot, zRot, position);
	SetShaderTexture("RugTexture");
	SetTextureUVScale(3.0f, 3.0f);
	m_basicMeshes->DrawPlaneMesh();

	// Floor
	scale = glm::vec3(20, 1, 10);
	position = glm::vec3(0);
	SetTransformations(scale, xRot, yRot, zRot, position);
	SetShaderColor(1, 1, 1, 1);
	m_basicMeshes->DrawPlaneMesh();

	// Table
	scale = glm::vec3(15, 7, 15);
	position = glm::vec3(0);
	SetTransformations(scale, xRot, yRot, zRot, position);
	SetShaderTexture("WoodTexture");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// Bottle Body
	scale = glm::vec3(1, 3, 1);
	position = glm::vec3(3.0f, 7.5f, -3.0f);
	SetTransformations(scale, xRot, yRot, zRot, position);
	SetShaderTexture("WaterTexture");
	m_basicMeshes->DrawCylinderMesh();

	// Bottle Neck
	scale = glm::vec3(0.8f, 1.5f, 0.8f);
	position = glm::vec3(3.0f, 10.35f, -3.0f);
	SetTransformations(scale, xRot, yRot, zRot, position);
	SetShaderTexture("BottleTexture");
	m_basicMeshes->DrawCylinderMesh();

	// Cap
	scale = glm::vec3(0.87f, 0.4f, 0.87f);
	position = glm::vec3(3.0f, 11.72f, -3.0f);
	SetTransformations(scale, xRot, yRot, zRot, position);
	SetShaderColor(1, 1, 1, 1);
	m_basicMeshes->DrawSphereMesh();

	// Coaster as thin cylinder (adds depth)
	scale = glm::vec3(1.5f, 0.1f, 1.5f);
	position = glm::vec3(3.0f, 7.1f, -3.0f);
	SetTransformations(scale, xRot, yRot, zRot, position);
	SetShaderTexture("CoasterTexture");
	m_basicMeshes->DrawCylinderMesh();

	// Laptop base (3D box)
	scale = glm::vec3(4.5f, 0.2f, 3.0f);
	position = glm::vec3(-4.0f, 7.3f, 2.5f);
	SetTransformations(scale, xRot, yRot, zRot, position);
	SetShaderTexture("LaptopbaseTexture");
	m_basicMeshes->DrawBoxMesh();

	// Laptop screen (angled upright box)
	scale = glm::vec3(4.5f, 3.0f, 0.2f);
	position = glm::vec3(-4.0f, 8.6f, 0.50f);
	xRot = -30.0f;
	SetTransformations(scale, xRot, yRot, zRot, position);
	SetShaderTexture("LaptopscreenTexture");
	m_basicMeshes->DrawBoxMesh();

	// Laptop screen (window)
	scale = glm::vec3(2.0f, 10.0f, 1.0f);
	position = glm::vec3(-4.0f, 8.6f, 0.65f);
	xRot = 60.0f;
	SetTransformations(scale, xRot, yRot, zRot, position);
	SetShaderTexture("LaptopwindowTexture");
	m_basicMeshes->DrawPlaneMesh();

	// Funnel Cone
	scale = glm::vec3(1);
	position = glm::vec3(3.0f, 10.5f, -3.0f);
	SetTransformations(scale, 0, 0, 0, position);
	SetShaderTexture("BottleTexture");
	m_basicMeshes->DrawConeMesh();
}