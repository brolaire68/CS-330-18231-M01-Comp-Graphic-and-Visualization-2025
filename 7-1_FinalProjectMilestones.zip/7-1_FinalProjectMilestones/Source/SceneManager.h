#pragma once

#include <string>
#include <vector>
#include <glm/glm.hpp>
#include "ShaderManager.h"
#include "ShapeMeshes.h"

class SceneManager
{
public:
	SceneManager(ShaderManager* pShaderManager);
	~SceneManager();

	void PrepareScene();
	void RenderScene();

	bool CreateGLTexture(const char* filename, std::string tag);
	void BindGLTextures();
	void DestroyGLTextures();

	void SetShaderColor(float redColorValue, float greenColorValue, float blueColorValue, float alphaValue);
	void SetShaderTexture(std::string textureTag);
	void SetTextureUVScale(float u, float v);
	void SetTransformations(glm::vec3 scaleXYZ, float XrotationDegrees, float YrotationDegrees, float ZrotationDegrees, glm::vec3 positionXYZ, glm::vec3 offset = glm::vec3(0));
	void SetShaderMaterial(std::string materialTag);

	int FindTextureID(std::string tag);
	int FindTextureSlot(std::string tag);

	// NEW: These were missing!
	void DefineObjectMaterials();
	void SetupSceneLights();

private:

	// Texture info struct
	struct TEXTURE_INFO {
		GLuint ID;
		std::string tag;
	};

	// NEW: Object material struct
	struct OBJECT_MATERIAL {
		std::string tag;
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float shininess;
	};

	bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

	ShaderManager* m_pShaderManager;
	ShapeMeshes* m_basicMeshes;

	int m_loadedTextures = 0;
	TEXTURE_INFO m_textureIDs[16];  // Up to 16 texture slots

	std::vector<OBJECT_MATERIAL> m_objectMaterials;
};